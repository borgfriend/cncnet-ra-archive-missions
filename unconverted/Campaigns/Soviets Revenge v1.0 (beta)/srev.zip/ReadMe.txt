BETA TEST- Soviets Revenge v1.0

NEEDED FILES: 
First of all you need Aftermath installed.
When playing these missions uses the SOVIET DISK or you will not
get the bets quality missions I can offer.

The following files should be in a .zip file called SRev.zip and if
not do not do use files.

---    ReadMe.txt
---    mission.ini
---    scu01ea.ini
---    scu02ea.ini
---    scu02eb.ini

Move all the files which contain .ini at the end into your Red
Alert directory.

If all the files are not moved into it, even if the file contains
no information, the mission may not work correctly and may have a
chance of crashing.

HOW TO START MISSION: 
At the title screen of Red Alert click start new game.
Then click SOVIET.  Now your all set.