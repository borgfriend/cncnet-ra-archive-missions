Sine Taiwan War created by ????????????????????

This is a campaign that is based on the war between China and Taiwan.
Which haven't happen yet or will never happen.
There is 6 missions for each side and the rules.ini has been edited 
to be more realistic. 

Storyline:
	May 3 Year 2001, one year after Taiwan's new president Chan was elected.
He claimed taiwan independent, which China would not allow. China had no option
but to take over taiwan by force. The U.S had agreed to aid Taiwan if China have
attacked. China had advanced technology from USSR, Taiwan has the U.S to aid them.
Choose to aid either side in the combat.