
 ==================================
     Red Alert: Campaign Ultraq
 http://www21.brinkster.com/ultraq/
 ==================================

  1) Unzip all the files:
       - Ultraq.bat
       - Ultraq.cow
       - Ultraq.moo
       - Ultraq - ReadMe.txt
     to your Red Alert directory, eg: C:\Games\C&C Red Alert\

  2) Run the batchfile called "Ultraq" for final installation.

       The batchfile can also be used to remove the Campaign,
       however this will still leave the files mentioned above in
       your Red Alert directory.  So delete them as well to
       completely clear your Red Alert directory of those files.

 "Enjoy!"

 - Emanuel Rabina, LightninUltraq@Netscape.net
