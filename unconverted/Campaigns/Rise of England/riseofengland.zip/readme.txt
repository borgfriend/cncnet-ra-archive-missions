"Rise of England"

	This campaign was created by Ben Cheever (chevanater@yahoo.com) and if you wish to put this on your web site, give me a link in your links section (http://www.angelfire.com/wi/chevsmain/index.html) or give me credit for the campaign. Please email if you are going to put it on your website, so I can link you to my page.
			thanks,
			 Ben Cheever (chevanater@yahoo.com)