AFTERMATH GIANT ANT CAMPAIGN
----------------------------
Version 1.11

Written by Brian Bird
See http://ra.tiberiumsun.com/
for more details

Installation
------------

Unzip the entire contents of the Aftermath Giant Ant campaign into your
main Red Alert directory (usually C:\WESTWOOD\REDALERT). Overwrite any
files that are already in the directory. (This will only happen if you
have installed other third party missions or add-ons).
Now start Red Alert and play a new Allies campaign. I have only tested
the missions on Normal skill level, but any skill level should work.
Note you will need Red Alert and Aftermath installed to play this capaign.
Comments or suggestions are welcome.