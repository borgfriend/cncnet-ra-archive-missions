copyright Raul Riera 98


This is a 4 missions mini campaing for the allies. To play it
just extract all the files in this zip file into your Red Alert
directory...

You should find in these zip file the next archives:

SCG01EA.INI
SCG02EA.INI
SCG03EA.INI
SCG04EA.INI (dont panic in this mission takes a little time to load)
MISSION.INI
TUTORIAL.INI
THE ONE YOU ARE READING RIGHT NOW...


ENJOY...


					THE GENERAL 
					rjriera@etheron.net
