Additional Readme added by PlanetCNC

Installation: 
Simply unzip the file contents to your game directory. For more help, 
please go to this page via the Internet 
"http://www.planetcnc.com/files/help/". To uninstall, simply 
remove the file(s).

Downloaded from PlanetCNC
http://www.planetcnc.com