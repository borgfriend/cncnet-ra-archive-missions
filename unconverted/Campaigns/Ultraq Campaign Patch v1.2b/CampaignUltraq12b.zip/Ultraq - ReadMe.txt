
 ==================================
     Red Alert: Campaign Ultraq
 http://www21.brinkster.com/ultraq/
 ==================================

  1) Unzip all the files:
       - Ultraq - ReadMe.txt
       - Ultraq.bat
       - Ultraq.cow
       - Ultraq.moo
     to your Red Alert directory, eg: C:\Games\C&C Red Alert\

  2) Run the program "Ultraq.bat" for final installation.

       The batchfile can also be used to remove the Campaign,
       however this will still leave the files mentioned above in
       your Red Alert directory.  So delete them as well to
       completely clear your Red Alert directory of those files.

  Enjoy!

 - Emanuel Rabina, LightninUltraq@Netscape.net

 ================================
 Patch Installation Instructions:
 ================================

  It is assumed that the original Campaign Ultraq files were
  left in the Red Alert directory.  If not, then unzip them into
  your Red Alert directory first.

  1) Unzip all the files:
       - Ultraq - ReadMe.txt
       - Ultraq.bat
       - UltraqX.cow
     into your Red Alert directory, overwriting files when prompted.

  2) Run the updated program "Ultraq.bat" and first select
     "2) Uninstall" to remove all the old version stuff.

  3) Then re-run the program and select "1) Install" to re-install
     the campaign and all updated files.

  Done!

    Installation will now always use the latest files.
