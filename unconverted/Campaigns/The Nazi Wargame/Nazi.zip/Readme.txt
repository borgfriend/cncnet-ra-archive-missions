----------------================-------------------
		THE NAZI WARGAME
----------------================-------------------
Welcome
=======
Thank's for downloading my Nazi Missions. There are
14 new Missions for each side but sorry, no conversions
of units or buildings. If there are any Bugs you find
Ie; Some triggers dont work, the Mission dosent Complete
after the Objective's been complete, then please e-mail
me at Perfectcell90@hotmail.com Thanx!

Installation
============
To install just unzip all the files into
your Red Alert Directory (usally C:\Westwood\redalert)
Sorry if you want to Uninstall You Have to Delete all 
the Ini Files Loaded in to it

Story
=====
Before Einstien could go back into the past to change
the events that have happened, a Bunch of kids Mug him
on his way back from the local store, and the Nazi's still
continue to do there Stuff, but This time the Russian's
have allied with them to attack the Allies and Destroy 
the Jewish Communities, the Powerfull allied Forces, do
not aprechiate this and help the Jews..........

Acknologments
=============
Thanx to Everyone for Downloading this!
If you like this you will love A New Era, 
Download it at 
Http:\\Www.Geocities.com\Nelsonstreet_Drummer
Witch includes 14 missions for each side
plus conversions! Including the Deadly 
Chemical Tank.

Requirments
===========
Red Alert - Aftermath 

Have Fun


Morgan English