Hi Red Alert fans!							October, 2nd, 2005

thanks for downloading my campaign, i hope you will like it.


Story: In this campaign for russians you capture in 8 missions the world for Mother-russia.

Installation: install all files in your red alert mainfolder and select sowjets side to play the campaign. 

requirements: To play this campaign you need the aftermath addon.

Info: The aftermath ini in this zipfile add the units into the build menue if you have it already in your mainfolder, make a backup of your aftermath.ini and replace it with mine.

Some hints:

Mission1 : Build submarines as soon as possible, you may possibly get a visit from South. and don't forget to build your mainforces, to rush the enemy.

Mission2 :  Contains a small bug. If you lose all your troops and submarines you have to restart the map manual.

Mission3 : Keep the Rocket grunts alive and release your soldiers with help of the rocketgrunts.

Mission4 : Hold the base for 35 minutes, and don't forget to train your troops in the background. You will need your men to destroy the enemy base. After reinforcements arrive, you must attack fast or the enemy will build his troops like in multiplayer and rush you to the hell.

Mission5 : Keep your troops together or this mission is really hard.

Mission6 : This is a real difficult mission, build as soon as possible 3 or 4 Tesla coils and many anti aircraft batteries or you will lose. Destroying the small Bridge will make the mission easier.

Mission7 : Beware of mines.. 

Mission8 : Build 2 or 3 harvesters for faster cash income.


////////////////////////////////////////////////////////////////////////////////////////////


If you have any Questions or difficulties playing Deadly War let me know..

Email: 23-Down@web.de

greetings 23-Down