Mission name:  Nuclear Storm
Author      :  Dennis Toepoel
Email       :  dennis@cruiser.vo.com
Side        :  Soviet
W x H       :  126 x 64
Theater     :  Snow
Date        :  31th of March 1997

Briefing:
The Allies have located the whereabouts of our main biochemical weapons'
plant. What is even worse, they infiltrated our base and set off a toxic gas
from one of the containers, killing everyone in the base. They kidnapped
Kosygin, one of Stalin's top atomic stratigic's generals. He has the
launchcodes for the Atomb Bomb we were working on. We MUST get him back
before the Allies extract the information from him and use our own most
dreadful weapon against us. We managed to steal an allied APC vehicle.

The base is too far away from our factories to supply you with any
reserves... if some building or unit is destroyed, it is gone. After your
primary mission is complete, wipe the Allied Dogs out of this area... Now go,
and do not return if you fail.

Instructions:
Unzip the Nuclear.zip file into your Red Alert game directory, after that,
run nuclear.bat to install this extra mission on your drive.
After play, run nukewipe.bat to get rid of the extra missionfiles again.
Make sure you have the Soviet CD in your CD-ROM drive if you want to see the
animations.
After booting Red Alert, select New Game, choose difficulty level (doesn't
matter much for this mission anyway) and select Soviet as your side... and
BANG, you're right into the action...

From the Author:
This is my first single-player mission I wrote, I hope you all like it...
It's pretty tough, so just keep trying, I managed to get there myself ;)

You may spread this zip file and all contents to anyone for play use as long
as you do not modify this message.

Special thanks to Andrew Griffin and Charles Francis Harkins for writing
their awesome RACG (The Red Alert Single Player Mission Creation Guide) for
without it, I would never have managed to make this mission.
