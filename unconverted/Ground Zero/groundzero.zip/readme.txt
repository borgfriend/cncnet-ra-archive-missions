***** RUN THE SAVEGAME (R) RUN NEW MISSION FOR ALLIES*** 

Oh. you decide to read this huh. Well, well, hmm let's
just say, this mission is a hum-dinger. May i suggest
you enjoy life first, before you attack this baby. She
is SSwweeettt. You will work your mouse constantly. ;).
War is hell, and this one has it all. By land,BY sea,
BY air. i dont wanna give you all the goodies, i'll let
you write me back for more...ha ha ..please do.I respond
to all e-mail.

            ****** THE MISSION ******
GROUNDZERO is not my map. I download the map off a site
that had mulitimap section. Hat's off to the creater of
it. I use it, to construct this mission, some of the 
maps i've seen is (rank). :/ no trees (maybe here and there
some are to open field..etc.etc..they dont look real to
me.but this one is nice.

Ussr has found a lost island off of africa, that has alot
of gem and ore. kane use this island to construct the 
future of his ((((  N.O.D ))). WE MUST STOP HIM AT ALL
COST..My next mission is "st.nicholas way" coming soon
look for it, on your favorite site, are e-mail me.

        GOOD GENERAL....
              WAITING ON YOUR E-MAIL..RONTO  