Target, Aim, Fire
======================
Author: VL
Made With: C&C Red Alert Scenario Editor
           Red Alert Single PLayer Creation Guide
======================
Storyline:
The USSR nuclear missles are aiming for England, you must stop them.
Kill all Soviets in the area, Ukraines as well. Use the transport to 
get Tanya and your Spy on Ukraine base to the island in the east. 
Once there, use Tanya to eliminate the Soviet Dogs and get the Spy 
in to the Missile Silo.
======================
Special Thanks To: The kind person who made C&C RAED
                   Andrew Griffin and C.F.Harkins for RACG
======================
Copyright Notice: Westwood Studios and Virgin Interactive are the 
                  trademarks of their respective owners.
                  The Red Alert Single PLayer Creation Guide is 
                  authored by Andrew Griffin and C.F.Harkins.
                  This Red Alert Single Player Mission is created by
                  VL for free distribution uder the circumstances 
                  that you do not modify, use with for the enhance-
                  ment of any product, made for download at 
                  Pay-Per-View sites or cost anything for the use of
                  this Mission and that you include this copyright 
                  information. For commercial requests, please send 
                  e-mail to h409@yahoo.com for evaluation. We reserve 
                  the rights to turn down your request.
======================
Notice: This Mission is in no way affiliated with Westwood Studios or 
        Virgin Interactive. We are not responsible for any damage 
        resulting from the play of this Mission. Please e-mail any 
        problems or bugs to h409@yahoo.com






