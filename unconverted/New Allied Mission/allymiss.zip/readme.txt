To play the .INI version of my new mission, copy SCG01EA.INI and MISSION.INI into the Red Alert folder on your hard drive.

Now, start either version of Red Alert.  Start a new game as the
Allies.  That's all you have to do.


-Shaun Lyle