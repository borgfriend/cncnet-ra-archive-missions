Name=Destructive Research
Size=64x160
Theater=Temprate
Side=Allies
Creator=Courtney Trammell (Deathaven) tobasco@yournet.com
Credits=Gavin Pugh for R.A.C.K. and Microsoft NotePad

Please do not tamper with the content of this .zip because if you do I can sue you, and contact me if you wish to place this file on your site.

This is a new version of Destructive Research. The computer will now build agaist you and you play as France. This is a good 
mission for both begginers and experts.