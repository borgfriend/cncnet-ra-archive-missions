            COMMAND AND CONQUER RED ALERT
                Top Secret missions

Please read

This Mission pack has only 1 mission on it because ive 
only just started making this whole scenario its a taster
of my mission pack Top Secret missions it does not have 
any breifings so here is the breifing

The soviets have taken over an allied base with our 
chronosphere inside it this is not acceptable! 
we have sent in our new weapons the chronotanks and a field mechanic.
send a spy into the radar dome,then destroy the construction
yard next to it.troops will come running and flare will
reveal power plants destroy all these and the gap generators
in the base will go offline aswell as the tesla coils so
you can get in and destroy everything and complete the mission.

To get the missions working just copy scg01ea.ini file
into your red alert directory select start new mission and
click on allies
