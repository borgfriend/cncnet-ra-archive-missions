++This file was downloaded from the TechCenter�++
                 www.planetcnc.com/ra-tech/
=========================================
Red Alert Revolution Mission Pak 1
-Check back frequently for updates
=========================================

INSTALLATION-

1.  Unzip everything to your Red Alert directory (usually c:/westwood/redalert/)
2.  Start the Allied campaign on "Brutal"
To uninstall simply delete the files that were added.
=======================================================
OTHER NOTES:
This replaces the first two allied missions with missions made for PR.
YOU MUST HAVE THE LATEST VERSION OF RED ALERT REVOLUTION INSTALLED!
=======================================================
If you find any bugs, please email me at puma__3@hotmail.com


Enjoy!
