THIS ONE'S A BITCH! YOU'VE BEEN WARNED! 
I don't want anyone writing email complaining that its 
too hard.  

Mission Title:  Mediterranean Oil
     Which CD:  Allies
       Player:  Allies (Germany)
         Type:  Single

Synopsis -
This is the first mission I ever created.  It was made
with GBRAedit version 1.2.3. It was made to illustrate
what can be done with GBRAedit, and what RA is really 
capable of, using custom missions. RA doesn't have to
look like a game (C'mon! Running over infantry?), and
missions DO NOT have to be wimpy.

This mission has just about everything. Reinforcement
teams for both sides, traps, pitfalls, swindles, and one
helluva bad-ass enemy!  You are gonna have to deal with
enemy paratroopers, migs, cruisers, and of course 
land units. Watch out for booby traps too!

You have 3 ways to lose, and only one way to win.
You're gonna make numerous attempts to get it right if
you are determined enough.  There are plenty of ways to
go wrong, and only a few to go right.  Just keep trying.
It CAN be beaten! You are gonna have to do some balls
out guns blazing toe to toe, and you're gonna need to 
do some very careful and intricate surgery too.

RULES.INI has been modified only slightly.  

  You will not be able to run over enemy infantry 
  with vehicles. 

  Artillery range has been increased slightly. 

  Your nuke has been slightly improved. 

The emphasis is on realism without digging real deep
into RULES.INI.

One thing for sure: You'll find this mission interesting,
and one helluva challenge.  But be warned... this one's
tough!  If you need a hint, send email, but only if
you really have tried and can't figure it out.

***********************************************
INSTALLATION
***********************************************
Extract all files from the zip file into
your Red Alert directory.  Then double-click the 
file Mediterr.bat.  This will copy the files in the
following manner:

   SCG01EA.MED  ->  SCG01EA.INI
   MISSION.MED  ->  MISSION.INI
   RULES.MED    ->  RULES.INI
   TUTORIAL.MED ->  TUTORIAL.INI

You are now ready to play the mission.  Simply start
Red Alert with the ALLIES CD in your CD ROM Drive. Then
choose Start New Game from the menu, and select Allies.

READ BOTH PAGES OF THE BRIEFING! Click the 'more'
button.

Removing the .INI files
---------------------
Double click the file MEDITRmv.bat.  All the above .INI
files will be removed from your Red Alert directory, and you
can play Red Alert without the RULES.INI in the way of
normal multiplayer games. 

NOTE: All .MED and .BAT files will remain in your Red Alert 
Directory.  If you want to play the mission again after 
playing with default settings, just run MEDITERR.BAT again.

********************************************
Copyright Len Goforth, July 24, 1997
goforth@rio.com

You may freely distribute the zip, provided that no
alterations are made to its contents or the files within.

Have fun!  
