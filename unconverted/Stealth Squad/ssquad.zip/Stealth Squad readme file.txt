
        ***************************************************************
        *Stealth Squad Version 1.02 - Red Alert single player scenario* 
        ***************************************************************
                  
Created by: Pookie (Guy Ulmer)

Created for: Command & Conquer: Red Alert

Release date: 26/3/97

Side: Soviets

Map info : Temperate. 64x32.

Programs used: Red Alert built in terrain editor, Microsofts notepad.

Help used: The red alert scenario creation guide v. 1.04, The Red Alert
           single player Mission Creation Guide.

Tested on: Red Alert v 1.04 Windows 95 version & DOS version.

Contact: Email - pookie@zigzag.pl
         Home Page - http://www.geocities.com/TimesSquare/Arcade/8131

Thanks to: * Gavin Pugh (for his red alert scenario creation guide and for 
             additional info).
           * Andrew Griffin (for his Red Alert single player Mission Creation 
             Guide)
           * CFH (For his Red Alert single player Mission Creation Guide and
             for helping me out with my mission
           * Osprey (for helping to solve almost everything within the mission
             and for a lot of additional info).
           * All the other people who beta-tested my mission!
           * And finally you - for trying it out!

BUGS LIST (READ IT):
I fixed almost everything in this version (A lot of help from Osprey and Gavin
Pugh there is only one bug left (as far as I know):
When uploading your commando into the chinook the chinoo will try to go
out of the screen because it thinks that he is a civilian and it tries
to evacuate him. This is strange because in the basic section I set 
CivEvac=no. I tried to overcome it by using another unit and giving it the
image and the info of the commando but it doesn't seem to work and I get the
normal image of the unit.
I decided to leave it as it is and to slow down the chinook so you will
have more time to move it somewhere else. By moving it to another point of
the screen the chinook will obey you until you upload the commando again.
I'm really sorry about it and if someone can help me out I would be really
glad.

MISSION BRIEFING:
Our spies have discovered that the allies are working on a new stealth
device and the process is near completion. If the operation is completed no 
force will be able to stop them. We need to get this device NOW!
Device is stored within a crate in a small isolated Allies outpost. You
will be enforced with our new commando unit and with a chinook. They will
greatly assist you in your mission. After retieving the device we need
you to destroy remaining Allied forces.
Exposion to the device in the crate can lead to interesting results, so be 
careful when taking it.
Make sure that the commando and the chopper will return safely to our base
in Moscow. Without the commando, we will never be able to find what the 
Allies are up to. Without the chinook, we can't get him back. Lose them, and
you will lose your life.

Copyright notice:
If you base your mission on this mission, please give credits.
You are not allowed to distribute the mission on computer magazines cover
disks or any CD missions pack. You are not allowed to charge money for
this mission.
You are illegaly allowed to distrubute this missions as long as you keep
it in this zip file and don't modify anything within it and as long
as you following this copyright notice.
The mission was created by Guy Ulmer (Pookie). All rights reserved (C) 1997.

YOU WANT MORE?
New missions and cool stuff can be found at my Home Page - The MissionForce:
Located at - http://www.geocities.com/TimesSquare/Arcade/8131 - Go there!
More missions including sequels to this mission and other missions will
be found there.
























