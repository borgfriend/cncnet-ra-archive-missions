Soviet World of WAR - Aftermath Mission created by Andy Vinall
--------------------------------------------------------------

Note: You need Red Alert: The Aftermath to play this mission.

Files packed with this Zip File:

Scg01ea.ini
Tutorial.ini
Mission.ini
Readme.txt

Instructions
------------
Unzip the files into your Red Alert Directory (Default is C:\WESTWOOD\Redalert\).
Start up Red Alert and goto New Game, then select your skill (Easy, Normal or Hard)
and then choose your side to be Allies. The Mission should start.

Troubleshooting
---------------

Question (Q): The computer locks up when I try the mission. Why?
Answer (A): There are many possible problems that occur with that.
1#: You haven't Unzipped all off the files to the Red Alert Directory.
2#: You haven't deleted Rules.ini and Aftrmath.ini (make backups if you want to).
3#: You don't have the Aftermath Installed or you don't have it.

If you have problems getting the mission to work, email me (address is down the bottom).
I hope you enjoy my Aftermath Mission. I used C&C Red Alert Scenario Edit V1.24 and Notepad
to create my mission.

Email: andilizem@geocities.com
Web Site: http://www.website2u.com/Andilizem
