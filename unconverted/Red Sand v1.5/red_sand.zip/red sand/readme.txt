Red Sand Vr. 1.5
By Jay
e-mail: jd0gg7@yahoo.com

=================================
=================================

Changes-

-Added Spitfire Icon for Yak
-Fixed German team bug that caused crashing
-Balanced APC team to not be so harsh on the player
-Named the damn thing =] (much better than "Beach Invasion mission")

This is one of my first missions. It isn�t the best but I don�t think it is that bad for my first try. 

You are England and have to storm the German occupied area. You have only a few lenders to work with and supplies are short, but you must push through the German coastline defense. The good news is the Germans do not have any air units in the area, and they lack any operational armor. A large amount of German infantry are stationed on the beach and they have been preparing for this for sometime. The beach may be mined and we are sure that there is only one brake in the natural ridge barrier that the Germans are using for defense. Show the Wehrmacht what the allies are made of!

