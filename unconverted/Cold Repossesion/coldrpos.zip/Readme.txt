Red Alert Single Player Scenario - By Richard Ling
--- ----- ------ ------ --------

Name:           COLD REPOSSESION

Objective:      Wipe out enemy

Description:

  This is a level for the allies and is called "Cold Repossesion". Basically,
you have to reclaim the stolen land by detroying every soviet unit and
structure.
  You start with quite a few units and 1 MCV.
There are 4 islands and Stalin occupies the bottom 2, while you start in the
top left. There is hardly any ore, so u may find that you will have to start
a base on another island. There is loads of ore on the island in the top right
corner of the map. You shouldnt come up against any soviet subs. The base is
quite well defended with lots of mammoth tanks.

Contact:        E-Mail me at:  RLing4@aol.com   with comments. Also my web site
                has loads of maps, levels and patches for Red Alert. The
                address is:   http://members.aol.com/rling4/index.htm


=========== Added by Red Alert Archive ===========
Downloaded from Red Alert Archive:
	http://www.rda1.go.to
==================================================