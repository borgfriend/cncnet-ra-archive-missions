River Rampage
===========
Made by Rob

This is a solo mission for the Soviets that replaces an Aftermath mission.
To play, put scu40ea.ini in your Red Alert directory. The run Red Alert, select New Missions from the main menu and click on River Rampage.
Have fun!

Questions or Comments?
cncedit_ron@yahoo.com