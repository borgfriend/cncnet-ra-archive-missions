COVERT OPPERATIONS MINI CAMPAIGN
=================================

This is a small mini campaign for the allies. Its only 4 levels but I think they are good ones.  I started a fifth level but got bored with it.

How to use:
Put the provided files in your red alert directory and start an allied campaign.

Mission overview:

MISSION 1: RESCUE
One of our special agents code named "Delphi" has been captured by the Soviets. The Information Delphi has is vital to our victory in this war. We have the location of a Soviet p.o.w. prison complex where we believe Delphi is being held. You mission is as follows: Use your strike force and infiltrate prison. Getting a spy into there Command Post should disable any defences. Once in the complex locate the building where Delphi is and get him out of there. Then bring Delphi back to the drop off point were a chinook will be
waiting to safely evacuate Delphi.

MISSION 2: ICBM
Agent Delphi has given us the location of a Soviet base where they are developing ICBM launchers. This base is extremely fortified. Use Tanya to travel through the western ridges and cut off there power supply. Be careful to stay away from there main enterance until the power is knocked out. Once the power is nocked out we will send reinforcments. Then destroy the base.

MISSION 3: DISTRACTIONS
We need to control the North side of the River in this area. Unfortunatly the Soviets already started a base there. The civillians twords the southwest are friendly to the Soviet cause. Use your provided tanks to attack the village. Doing so should cause the Soviets to counter attack. With them distracted sneak your MCV through the Soviet base and into the North-East. Establish your base then destroy the Soviet base from within.

MISSION 4: SPECC. OPPS.
We believe the Soviets are conducting chemical weapons research in a top secret base. The Bio labs must be destroyed. There is no room for a base here so you will have to be sneaky. Use your team to capture a nearby outpost. We do not have full details so you will have to do investigate for yourself. Once there outpost is captured use any means neccessary to destroy the bio labs.

QUESTIONS OR COMMENTS?
cncedit_rob@yahoo.com
