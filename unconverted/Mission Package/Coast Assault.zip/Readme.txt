Coast Assaul Version 1.0 final
Thanks for downloading!!!

-First I would like to warn you all. This is a very tough mission and it will probably take you a while to beat it. But dont give up. You will need to plan an attack before you invade the coast so make sure to think things threw before you act. If you have a computer 166Mhz or slower the game will go slow, I know because I have an old computer.

-STORY-
The Soviet Empire has captured France. They have completely blockaded the coast and fortified a strong nortern base. We deployed om a small southern 
island. Your MCV will arrive shortly. In the mean time remove any threats from the area so you can build a base. Ukraine has a small base on your island. You should remove them before they cause to much trouble. The remaining French military has retreated to the central island. Find them. They will follow any orders you give them. Your mission, work with france, invade the soviets beach front to the north, destroy everything. England has promised us Naval Cruisers, no telling when they will arrive. If you are destroyed, we loose France. Use any force nessacery to take the Soviets out, use a Nuke if you must.  

-To play this just put all this all in your red alert directory and make sure you have no mods installed or other rules files. Then start a new game as the allies. If you have any trouble getting it to work mail me at cncedit_rob@yahoo.com

I also included a few new units and sounds with this for your enjoyment.
-Commando & original voices
-Cruise missile frigates
-Subarine Destroyers
-Light Tesla Tanks
-Long range Artillery
-Plus more!!

Questions or Comments?
cncedit_rob@yahoo.com