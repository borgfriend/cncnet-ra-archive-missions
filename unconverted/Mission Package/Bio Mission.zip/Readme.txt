__________________________________________________________________________________________________________________________________________________________
BIO WARFARE PREVENTION
Made by Rob Nickel

-This is the second mission I have released for Red Alert. It is a hard mission. Have fun playing it and dont give up.

-To play it unzipp everything to your Red Alert directory and start a new game as the allies.

QUESTIONS OR COMMENTS?
cncedit_rob@yahoo.com

