Invasion form the Bearing Strait
======================
Made by Rob

This is the 3rd missions I have released for Red Alert. Its not as hard as the first 2 and I used new trigger techniques I never had before.

To play- Aftermath is required - this replaces an aftermath mission.
Unzipp all items to your Red Alert directory and start Red Alert. Select new missions then click on "Invasion from the bearing strait"
have fun playing.

Questions or Comments?
cncedit_rob@yahoo.com