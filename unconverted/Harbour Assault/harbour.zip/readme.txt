Red Alert Single Player Scenario - By Richard Ling
--- ----- ------ ------ --------

Name:           HARBOUR ASSAULT

Objective:      Defend relay stations at all costs, remove enemy.

Description:

  This is a level for the allies and is called "Harbour Assault". Basically,
You are under attack instantly from loads of V2's. Move your tanks to engage
and destroy them. If all your tanks are wiped out then the V2's will regroup
and start attacking the relay stations. Paratroopers will also pay a visit
so watch out. Your artillery's should take care of them. Also there are 4 V2s
on each side at the bottom. There are about 32 V2's all togethor and 4 mammoth
tanks.

Contact:        E-Mail me at:  RLing3@aol.com   with comments. Also my web site
                has loads of maps, levels and patches for Red Alert. The
                address is:   http://members.aol.com/rling3/index.htm

========== Added by Red Alert Archive ============

Downloaded from Red Alert Archive
	http://www.rda1.go.to
==================================================