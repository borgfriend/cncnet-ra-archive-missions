Tanya's Way
Author: Ted Rusk
Installation Instructions: Unzip the contents of this zip file into 
your Red Alert directory.
Description:
-Our objective is the destruction of  the technology centre. But to reach it, you will 
have to fight your way through the map, with minimal support.  Acquire combat material 
from the enemy and watch for signal flares. Tanya MUST survive or the mission will fail.  
Helicopter capability will be provided when the AA gun is blown, but DON'T lose it, it's 
your only one.  Stealth is imperative, as the enemy will react to our moves.

Support:
E-mail the author at "ted.rusk@3web.net".

Contents: scu01ea.ini (mission map file)
          readme.txt (this file)
