Name=Opeation "Mammoth Destruction"
Size=96a96
Theater=Temprate
Side=Allies
Creator=Courtney Trammell (Deathaven) tobasco@yournet.com
Credits=Gavin Pugh for R.A.C.K. and Microsoft NotePad

Please do not tamper with the content of this .zip because if you do I can sue you, and contact me if you wish to place this file on your site.

This mission expand on my previos mission and eleminates the Mammoth Tank from the war.
