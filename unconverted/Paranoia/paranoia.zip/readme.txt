Paranoia for Multiplayer Skirmish
Author: Ted Rusk
Installation Instructions: Unzip the contents of this zip file into 
your Red Alert directory.
Description:
Those pesky Cubans and Mexicans are more determined  than ever to ruin America's day, with 
the help of ... THE RUSSIANS!!!   Warning; Paranoia was devised to remedy the problem of 
attacks petering out toward the end, so don't get complacent. As always, defend against 
terrorists and main force units till backup arrives, kill the nuke silo before it 
kills YOU, and fight your way to SURVIVAL..

Support:
E-mail the author at "ted.rusk@3web.net".

Contents: scg01ea.ini (mission map file)
          readme.txt (this file)
