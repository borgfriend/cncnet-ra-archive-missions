Mission: Impossible
====================
Author: VL
Made With: Command & Conquer: Red Alert Scenario Editor 
Consulted File: The Red Alert Single Player Mission Creation Guide 
                by Andrew Griffin and C.F.Harkins
====================
Instructions:
1. Remove ALL scg01ea.ini and mission.ini files from your Red Alert 
   directory. (Be sure to backup them.)
   You can also remove/backup rules.ini to make this mission more
   original.
2. Copy scg01ea.ini and mission.ini into your Red Alert directory.
3. Start Red Alert.
4. Choose "Start New Game".
5. Choose "Allied".
6. Play.
====================
Story Line:
The Soviets have captured some of our troops, and taken them to the 
2nd Prison Area. Our resources in the area are limited. Watch out for
a large base in the southern area. Send your spy into the Prison 
Control Center or to scout the area. Make good use of time. Good luck!
====================
Please visit the author's home page, 
http://www.geocities.com/Hollywood/Makeup/7546
====================
Copyright Notice:

This mission is in no way affiliated with Westwood Studios.
You may distribute this mission freely as long as the files give credit
to their author, VL, and you do NOT charge any fee for using them. 
You may NOT alter this mission in part or in whole.
Command & Conquer, Command & Conquer: Red Alert and Westwood are
trademarks of Westwood Studios, Inc. All other registered trademarks
in this text belong to their respective owners.


