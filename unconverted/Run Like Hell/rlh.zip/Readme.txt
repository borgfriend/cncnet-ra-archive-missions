Run Like Hell
by Michael Covington (15yrs old)
_________________________________________________________

     This is the first single player mission that I have made. There will be many more where this one came from.
_______________________________________________________________________

Scg01ea.ini                                 ini file
Mission.ini                                  briefing file
Readme.txt                                 this file

Installation
	Unzip into your Red Alert directory
________________________________________________________________________

Story
	The soviets have taken germany and have nuke's aimed at 4 major citys across Europe. 50% of our forces are in these cities. You must stop the nukes.
________________________________________________________________________

Objective
	Get spy across the channel and into the Tech Center in the northeast corner of the map. I would advise using the APC.
________________________________________________________________________

Tactics
	Use the ACP to get inside the base and wipe out threat of dogs. RUN LIKE HELL.
________________________________________________________________________

Rules.ini modifications
[SPY]
Primary=Sniper
Strength=500

[SNIPER]
Range=4
________________________________________________________________________

Enjoy